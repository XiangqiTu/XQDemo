//
//  TextEffectViewController.m
//  XQDemo
//
//  Created by XiangqiTu on 15-8-3.
//
//

#import "TextEffectViewController.h"
#import "TextEffectView.h"

@interface TextEffectViewController ()

@property (nonatomic, strong) TextEffectView    *textEffectView;

@end

@implementation TextEffectViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"Text Effect";
    
    [self.view setBackgroundColor:[UIColor blackColor]];
    
    self.textEffectView = [[TextEffectView alloc] initWithFrame:CGRectMake(0, 0, 320, 320)];
    [self.view addSubview:self.textEffectView];
    
    self.textEffectView.center = self.view.center;
    
    [self.textEffectView startAllAnimations:nil];
    
}


@end
