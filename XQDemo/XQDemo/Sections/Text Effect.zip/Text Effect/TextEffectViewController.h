//
//  TextEffectViewController.h
//  XQDemo
//
//  Created by XiangqiTu on 15-8-3.
//
//

#import <UIKit/UIKit.h>

@interface TextEffectViewController : UIViewController

@end
