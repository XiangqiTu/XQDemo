//
//  TextEffectView.h
//
//  Code generated using QuartzCode 1.21 on 15-8-3.
//  www.quartzcodeapp.com
//

#import <UIKit/UIKit.h>

@interface TextEffectView : UIView


- (IBAction)startAllAnimations:(id)sender;

@end